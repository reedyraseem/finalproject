from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, Field
from sqlalchemy.testing import db

import models
from database import engine, SessionLocal
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
models.Base.metadata.create_all(bind=engine)
origins = [
    "http://localhost:8000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers={'*'},
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class FanastyFootball(BaseModel):
    id: int = Field()
    Name: str = Field(min_length=1)
    Position: str = Field(min_length=1)
    Team: str = Field(min_length=1)
    AVG_Points: int = Field(gt=1, lt=101)


FOOTBALL = []


@app.get("/fanastyfootball/")
def read_api(db: Session = Depends(get_db)):
    return db.query(models.FanastyFootball).all()


@app.post("/fanastyfootball/")
def create_fanastyfootball(football: FanastyFootball, db: Session = Depends(get_db)):
    football_model=models.FanastyFootball(
        Name=football.Name,
        Team=football.Team,
        Position=football.Position,
        AVG_Points=football.AVG_Points
    )

    db.add(football_model)
    db.commit()
    db.refresh(football_model)
    return football_model



@app.put("/{football_Id")
def update_fanastyfootball(football_id: int ,football:FanastyFootball,  db: Session = Depends(get_db)):

 football_model = db.query(models.FanastyFootball).filter(models.FanastyFootball.id == football.id)

 if football_model is None:
   raise HTTPException(
         status_code=404,
         detail=f"ID {football_id} : Does not exist"
     )

 football_model.id = football.id
 football_model.Name = football.Name
 football_model.Team = football.Team
 football_model.Position = football.Position
 football_model.AVG_Points= football.AVG_Points
 db.add(football_model)
 db.commit()

@app.delete("/{football_id}")
def delete_football(football_id: int, db: Session = Depends(get_db)):

    football_model = db.query(models.Football).filter(models.FanastyFootball.id == football_id).first()

    if football_model is None:
        raise HTTPException(
            status_code=404,
            detail=f"ID {football_id} : Does not exist"
        )

    db.query(models.FanastyFootball).filter(models.FanastyFootball.id == football_id).delete()
    db.commit()


