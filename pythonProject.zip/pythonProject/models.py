from sqlalchemy import Column, Integer, String
from database import Base


class FanastyFootball(Base):
    __tablename__ = "2013FF"

    id = Column(Integer, primary_key=True, index=True)
    Name = Column(String)
    Position = Column(String)
    Team = Column(String)
    AVG_Points = Column(Integer)
